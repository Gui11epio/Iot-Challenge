Nome: Pedro Manzo Yokoo/ rm:556115

Nome: Fernando Fernandes Prado/ rm:557982

Nome: Guilherme Camasmie Laiber de Jesus/ rm:554894
# Iot-Challenge


=COMO USAR O CODIGO(Alterar o código)

  ===ARDUINO IDE====

=1 Abra a ide do arduino e abra o arquivo do arduino(Alterar_inform_RFID)

- Em 'file' e depois 'open' e selecione o arquivo(Alterar_inform_RFID):
  
![Captura de tela 2025-05-16 105523](https://github.com/user-attachments/assets/7d4895f4-ee8a-44d5-9289-3b2daae4fec5)

- E selecione qual é o IOT nesse caso o esp32, selecione o (DevModule):

  (Imagem)

- E depois é só rodar o codigo em 'Upload':
  
![Captura de tela 2025-05-16 112715](https://github.com/user-attachments/assets/f95c256b-a223-40c8-9644-536dfdfa06dc)


=2 Abra o appScripts(https://script.google.com) e cole codigo que está no .txt(Alterar_inform_appScript.txt)
    - Depois de colar aperte em 'Implementar':
    ![Captura de tela 2025-05-16 110311](https://github.com/user-attachments/assets/dc83ef3b-3740-409b-8d99-eec16f5950d4)
    
   - Depois em 'Nova Implementação' e é muito IMPORTANTE deixar a opção 'Quem pode acessar' em 'Qualquer pessoa':
        ![image](https://github.com/user-attachments/assets/16f6980c-4850-4aa1-b2b5-dc0f18b98c2c)


#COMO USAR O CODIGO(Ler)
- É basicamente o mesmo processo mas com os arquivos para ler
    -Arduino IDE:
    - Na IDE abra o arquivo(Ler_Inform_RFID) para ler o RFID
    - No appScript cole o codigo para ler(Ler_inform_appScript.txt) e depois é só implementar
      
*PARA PODER VER AS INFORMAÇÕES DO RFID É SÓ ACESSAR O spreadsheets(https://docs.google.com/spreadsheets)
e coloque esse nome na planilha 'Acesso RFID':
![image](https://github.com/user-attachments/assets/9c7f663b-ddf4-4f78-89a3-262c536f5648)
